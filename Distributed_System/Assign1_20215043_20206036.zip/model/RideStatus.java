package model;
public enum RideStatus {
    ACCEPTED,     
    ON_THE_WAY,   
    ARRIVED,      
    STARTED,      
    COMPLETED,    
    CANCELED      
}
